Date of writing: 2020-03-25

--------------------------------------------------------------------------------

This archive comes with two MP3 files:
- Rail Romanesque Instrumental.mp3
- Rail Romanesque Instrumental (Vibraphone).mp3

The former ("Rail Romanesque Instrumental.mp3") is an updated version, which
includes changes made to the score on March 25, 2020. The main change versus the
previous version is that the vibraphone part was replaced with a glockenspiel
part. All files have been updated/replaced, including the MP3 file.

The latter ("Rail Romanesque Instrumental (Vibraphone).mp3") is the older
version made available when this archive was first published on March 21, 2020.
This version matches the audio played in the YouTube video featuring the play-
back of this transcription (seen here: https://youtu.be/Tpht8Ohd88o).

For your listening pleasure, both the updated and the original MP3s are provided
to you. You have the option to keep one or the other or both. Please keep in
mind that the MP3 metadata (i.e. the album cover, the song title, artist, album,
etc.) is IDENTICAL between BOTH MP3 files. Please be aware of this if you
decide to put both MP3s on an MP3 player.

I personally like the updated one better since it's truer to the original song,
but I think both sound great to listen to either way.

--------------------------------------------------------------------------------

TL;DR:
- Vibraphone part was replaced with a glockenspiel part on March 25, 2020.
- A new MP3 file with this change included is available.
- The old MP3 file is also available for anyone who likes the version in my
  video demonstrating this transcription.

Thanks again for downloading my transcription; it means a lot to me. Enjoy!
- James Hyun