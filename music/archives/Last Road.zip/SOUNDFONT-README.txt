Date of writing: 2020-07-04 (July 4)

--------------------------------------------------------------------------------

This transcription uses a Bell Tree soundfont that was put together by myself,
i.e. it is not a soundfont that comes with any other publicly available
soundfont.

This download does NOT include the soundfont, but if you need it for any reason,
you may download the soundfont at the following address:
https://dev.1230james.xyz/misc/

Scroll down to "Bell Tree Soundfont" and press the button labeled "BellTree.sf2"
to download the soundfont. You may use the soundfont as you see fit without any
restrictions.

Please note: this is the first soundfont I've ever made, and was just set up
so I could get the sound into my notation software. It (probably) does not fully
comply with any MIDI specifications beyond the file format. Please be aware of
this if you plan to use the soundfont for your own works.

Additionally, for compatibility, the bell tree hits at the start of the song
have been removed for the MIDI file (but only the MIDI file).

Thanks again for downloading my transcription; it means a lot to me. Enjoy!
- James Hyun